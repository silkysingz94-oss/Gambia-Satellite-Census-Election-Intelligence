
from flask import Flask, jsonify, send_from_directory, abort
from pathlib import Path
import pdfplumber
import re

BASE_DIR = Path(r"C:\Users\ansu.s\Desktop\WEB MAPS\ELECTION")
app = Flask(__name__)

@app.route("/")
def home():
    return send_from_directory(BASE_DIR, "index.html")

@app.route("/api/elections")
def elections():
    documents = []

    for pdf_path in sorted(BASE_DIR.rglob("*.pdf")):
        try:
            pages_text = []
            page_count = 0

            with pdfplumber.open(pdf_path) as pdf:
                page_count = len(pdf.pages)

                for page in pdf.pages:
                    text = page.extract_text(
                        layout=False,
                        x_tolerance=2,
                        y_tolerance=3
                    ) or ""
                    pages_text.append(text)

            full_text = "\n\n".join(pages_text)

            year_match = re.search(
                r"(?:19|20)\d{2}",
                pdf_path.name
            )

            documents.append({
                "filename": str(pdf_path.relative_to(BASE_DIR)),
                "year": int(year_match.group()) if year_match else None,
                "pages": page_count,
                "text": full_text
            })

        except Exception as error:
            documents.append({
                "filename": str(pdf_path.relative_to(BASE_DIR)),
                "year": None,
                "pages": 0,
                "text": "",
                "error": str(error)
            })

    return jsonify({
        "folder": str(BASE_DIR),
        "pdf_count": len(documents),
        "files": documents
    })

@app.route("/api/files")
def files():
    result = []

    for path in BASE_DIR.rglob("*.pdf"):
        result.append(str(path.relative_to(BASE_DIR)))

    return jsonify(result)

if __name__ == "__main__":
    if not BASE_DIR.exists():
        raise FileNotFoundError(f"Election folder not found: {BASE_DIR}")

    print("GBoS GEOAI Election Dashboard")
    print(f"Scanning: {BASE_DIR}")
    print("Open: http://127.0.0.1:5000")

    app.run(host="127.0.0.1", port=5000, debug=False)
