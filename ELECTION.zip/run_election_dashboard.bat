
@echo off
cd /d "C:\Users\ansu.s\Desktop\WEB MAPS\ELECTION"

python -m pip install flask pdfplumber

python election_server.py

pause
